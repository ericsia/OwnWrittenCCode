/* add a ? behind the variable name to represent it's optional.
   text is for placeholder: the grey text that go away when u type
    
   Use /** to make comment so when others use your component suggestion will show it.
*/
export interface OTProps {
  /** when user picked the right time, the correct time format will set automatically
   *  if submit is click but string is empty u can assume user chosen 08:00-17:00
   */
  setTimeString(value: string): void;
  distanceTop?: number;
  titleDistanceBottom?: number;
}
