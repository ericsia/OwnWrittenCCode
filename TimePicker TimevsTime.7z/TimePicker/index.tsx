/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-native/no-color-literals */
import React, { useState } from "react";
import { StyleSheet, View, Text } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";

// Ribbon from props.tsx
import { OTProps } from "./props";

export function TimePicker(objOT: OTProps) {
  // initialise like this (Object Destructuring) so argument is optional
  const { setTimeString, distanceTop = 8, titleDistanceBottom = 3 } = objOT;

  // variable
  const [dateFrom, setDateFrom] = useState(new Date(883151700000));
  // can't remove must use include
  // const [dateTo, setDateTo] = useState(new Date(883126800000));

  const [timeFrom, setTimeFrom] = useState("23:55");
  const [timeTo, setTimeTo] = useState("23:55");

  const [show, setShow] = useState(false);
  const [to, setTo] = useState(false); // second textbox need setresult

  /** function start - keep a block comment as a label ##################### */
  function timeToString(date) {
    let temp = "";
    const h = date.getHours();
    const m = date.getMinutes();
    h < 10 ? (temp = "0" + h) : (temp += h);
    temp += ":";
    m < 10 ? (temp += "0" + m) : (temp += m);

    if (to) {
      if (date > dateFrom) {
        setTimeString(timeFrom + "-" + temp);
      } else {
        alert(
          "Your time is earlier or same as the Operating time please choose again"
        );
      }
      setTimeTo(temp);
    } else {
      setTimeFrom(temp);
      setDateFrom(date); // will use for validation
    }
  }
  function onChange(event, selectedDate) {
    let currentDate = selectedDate || dateFrom;
    setShow(false);
    timeToString(currentDate);
  }

  /** function end - keep a block comment as a label ####################### */

  // styles is always above return
  const styles = StyleSheet.create({
    groupFromTo: {
      flexDirection: "column",
      marginTop: distanceTop,
      width: "48%"
    },
    textBox: {
      alignItems: "center",
      borderColor: "#4185d9",
      borderRadius: 12,
      borderWidth: 1,
      height: 41,
      justifyContent: "center"
    },
    title: {
      alignSelf: "flex-start",
      color: "#444444",
      fontSize: 16,
      fontWeight: "700",
      marginBottom: titleDistanceBottom
    }
  });
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: distanceTop
      }}>
      <View style={styles.groupFromTo}>
        <Text style={styles.title}>Operating From</Text>
        <View
          style={styles.textBox}
          onTouchEnd={() => {
            setShow(true);
            setTo(false);
          }}>
          <Text style={{ color: "black", fontSize: 16 }}>{timeFrom}</Text>
        </View>
        {show && (
          <DateTimePicker
            value={dateFrom}
            mode="time"
            is24Hour
            display="default"
            onChange={onChange}
            minuteInterval={5}
          />
        )}
      </View>
      <View style={styles.groupFromTo}>
        <Text style={styles.title}>Operating To</Text>
        <View
          style={styles.textBox}
          onTouchEnd={() => {
            setShow(true);
            setTo(true);
          }}>
          <Text style={{ color: "black", fontSize: 16 }}>{timeTo}</Text>
        </View>
        {show && (
          <DateTimePicker
            // after consideration, shouldn't help user set time say 5pm
            value={dateFrom}
            mode="time"
            is24Hour
            display="default"
            onChange={onChange}
            minuteInterval={5}
          />
        )}
      </View>
    </View>
  );
}
