import styled from "styled-components/native";
import { StyleSheet } from "react-native";

export const Root = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const styles = StyleSheet.create({
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
  },
  inputContainerStyle: {
    borderColor: "#90afff",
    marginTop: 16,
    width: "90%"
  },
  leftIcon: {
    alignSelf: "center",
    marginLeft: 10
  }
});
