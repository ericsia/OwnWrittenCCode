export interface Screen1Props {
  title: string;
  loading: boolean;
  onPressButton: () => void;
  inputRef: any;
  value: number;
  setValue: (input: number) => void;
  error: boolean;
}
