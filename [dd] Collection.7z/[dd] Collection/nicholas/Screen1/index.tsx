import React, { useRef, useState } from "react";
import { useStores } from "models";
import { Screen1 } from "./component";
import { TextInput } from "react-native";
// Handles data and methods needed in render and pass it to component.tsx
export const ExampleScreen1 = () => {
  // --------------------STATES & VARIABLES
  const [loading, setLoading] = useState<boolean>(false);
  const inputRef = useRef<TextInput>(null);
  const [value, setValue] = useState(69);
  const [error, setError] = useState<boolean>(false);
  // --------------------HOOKS

  // --------------------FUNCTIONS
  const onPressButton = () => {
    setError(true);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setError(false);
    }, 1000);
  };
  // --------------------RENDER
  return (
    <Screen1
      loading={loading}
      onPressButton={onPressButton}
      title="This is screen1"
      inputRef={inputRef}
      value={value}
      setValue={setValue}
      error={error}
    />
  );
};
