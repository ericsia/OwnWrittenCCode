import React, { useRef, useState } from "react";
import { Text, StyleSheet, View, ImageBackground } from "react-native";
import { Button, CircularLevel, ShakeableTextBox } from "components";
import { observer } from "mobx-react-lite";
import { Root, styles } from "./styles";
import { Screen1Props } from "./props";
import { FontAwesome5 } from "@expo/vector-icons";

const PaswordIcon = <FontAwesome5 name="lock" size={22} />;

// Handles rendering screen, receive data and methods needed from index as props
export const Screen1 = observer((props: Screen1Props) => {
  const {
    title,
    onPressButton,
    loading,
    inputRef,
    value,
    setValue,
    error
  } = props;

  // eslint-disable-next-line no-return-assign
  return (
    <ImageBackground
      source={require("../../../assets/images/signup.png")}
      style={styles.image}>
      <Root>
        <Text> {title} </Text>
        <CircularLevel currentValue={value} radiusSize={35} color="blue" />
        <View style={{ width: "78%" }}>
          <ShakeableTextBox
            title="Title"
            ref={inputRef}
            containerStyle={styles.inputContainerStyle}
            isPassword
            leftIcon={PaswordIcon}
            leftIconWrapperStyle={styles.leftIcon}
            placeholder="This is a placeholder"
            hasError={error}
          />
        </View>

        <Button
          mode="small"
          text="- 23"
          style="marginTop: 10px; marginBottom: 10px"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={() => (value > 0 ? setValue(value - 23) : "")}
        />
        <Button
          mode="small"
          text="reset"
          style="marginBottom: 10px"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={() => (value === 69 ? setValue(0) : setValue(69))}
        />

        {/* This is how you comment */}
        <Button
          mode="small"
          text="Have Error"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={onPressButton}
        />
      </Root>
    </ImageBackground>
  );
});
