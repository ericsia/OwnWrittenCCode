# Components

Store simple re-usable React components that mostly handles UIs and simple actions, such as buttons and text fields.

Each component have their own folder, named after export name in PascalCase. Each component contains:

- `index.tsx` - exports `PascalName`, main file of each component and imports contents needed from `./props.ts` and `./styles.tsx`.
- `props.ts` - exports `PascalNameProps`, props passed to component to modify usage.
- `styles.tsx` - stores all styling related.
- other possible files, such as `types` or `data` can be added separately in the same folder
