import styled from "styled-components/native";
import { color } from "theme";

// styling for component
export const Container = styled.TouchableOpacity`
  align-items: center;
  background-color: ${color.primary};
  border-radius: 50px;
  elevation: 5;
  justify-content: center;
  /* condition by props: "mode" */
  ${(prop: { theme: { mode?: string; style?: string } }) => {
    const { mode, style = "" } = prop.theme;
    const size =
      mode === "small"
        ? `height: 30px; width: 100px;`
        : `height: 50px; width: 80%;`;
    return `${size}${style}`;
  }}
`;

export const ButtonText = styled.Text`
  color: ${color.textDarkBg};
  ${(prop: { theme: { mode?: string; textStyle?: string } }) => {
    const { mode, textStyle = "" } = prop.theme;
    const fontSize = mode === "small" ? `font-size: 14px;` : `font-size: 20px;`;
    return `${fontSize}${textStyle}`;
  }}
`;
