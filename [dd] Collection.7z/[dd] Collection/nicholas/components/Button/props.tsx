// stores component props
export interface ButtonProps {
  /**
   * changes the layout of the button
   * populate and use it to condition common button stylings used throughout the app
   */
  mode?: "small" | "submit";

  /**
   * change button container styling
   */
  style?: string;

  /**
   * change text styling
   */
  textStyle?: string;

  /**
   * button text, default "Confirm"
   */
  text?: string;

  /**
   * handles button on press
   */
  onPress?: () => void;

  /** disable onPress, blur button */
  disabled?: boolean;

  /** show loading indicator instead of text, disable and blur button */
  loading?: boolean;
}
