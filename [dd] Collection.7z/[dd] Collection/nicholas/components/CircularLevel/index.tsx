import React, { useRef, useEffect } from "react";
import { Easing, TextInput, Animated, View, StyleSheet } from "react-native";
import Svg, { G, Circle } from "react-native-svg";

// CircularLevelProps from props.tsx
import { CircularLevelProps } from "./props";

/*
  If you want to label the fullness of the bin then you might want to use it.
  Example 60% full in component.tsx:
      - import { CircularLevel } from "components";
      - usage <CircularLevel currentValue={69} color="blue" />
      - you may want to consider radiusSize

 */
const ANIMATED_TEXT_INPUT = Animated.createAnimatedComponent(TextInput);

export function CircularLevel(objCL: CircularLevelProps) {
  // initialise like this (Object Destructuring) so argument is optional
  const {
    currentValue = 69,
    maxValue = 100,
    radiusSize = 30,
    thickness = radiusSize / 5,
    duration = 500,
    color = "green"
  } = objCL;

  /* initialized as part of state, keep constant capital letter so others dev
     can differentiate easier which is internal which is own written
     especially the one very close to component/API name */
  const ANIMATED = useRef(new Animated.Value(0)).current;
  const CIRCLE_REF = useRef<Circle>();
  const TEXT_INPUT_REF = useRef<TextInput>();
  const circumference = 2 * Math.PI * radiusSize;
  const totalRadius = radiusSize + thickness;
  const boxSize = radiusSize * 2;
  const innerSize = totalRadius * 2;

  // clockwise the increment circle
  function animation(toValue: number) {
    return Animated.timing(ANIMATED, {
      delay: 1000,
      toValue,
      duration,
      useNativeDriver: true,
      // just own preference of the animation style
      easing: Easing.out(Easing.ease)
    }).start();
  }

  useEffect(() => {
    animation(currentValue);
    ANIMATED.addListener(
      //  animate a progress value from v and if it reaches, then fire an action
      (v) => {
        // just ratio formula
        const toRatio = v.value / maxValue;
        const strokeDashoffset = circumference - circumference * toRatio;

        if (TEXT_INPUT_REF?.current) {
          TEXT_INPUT_REF.current.setNativeProps({
            text: `${Math.round(v.value)}`
          });
        }
        if (CIRCLE_REF?.current) {
          CIRCLE_REF.current.setNativeProps({
            strokeDashoffset
          });
        }
      },
      [maxValue, currentValue]
    );

    return () => {
      ANIMATED.removeAllListeners();
    };
  });

  /* Below will use absoluteFill which is shortcut for
     position: 'absolute',
     top: 0,
     left: 0,
     bottom: 0,
     right: 0
     Inside the styles, name it with Style at the back, ex: textStyle
  */
  const styles = StyleSheet.create({
    textStyle: {
      color,
      fontSize: radiusSize / 2,
      fontWeight: "700",
      textAlign: "center"
    }
  });

  return (
    /* we draw a fade circle first then follow by the solid color circle
       G is grouping, use G rotate it counterclockwise 90* from the half
       strokeLinecap is to rounded the stroke */
    <View style={{ width: boxSize, height: boxSize }}>
      <Svg
        height={boxSize}
        width={boxSize}
        viewBox={`0 0 ${innerSize} ${innerSize}`}>
        <Circle
          cx="50%"
          cy="50%"
          r={radiusSize}
          stroke={color}
          strokeWidth={thickness}
          strokeLinejoin="round"
          strokeOpacity=".1"
        />
        <G rotation="-90" origin={`${totalRadius}, ${totalRadius}`}>
          <Circle
            ref={CIRCLE_REF}
            cx="50%"
            cy="50%"
            r={radiusSize}
            stroke={color}
            strokeWidth={thickness}
            strokeLinecap="round"
            strokeDashoffset={circumference}
            strokeDasharray={circumference}
          />
        </G>
      </Svg>
      <ANIMATED_TEXT_INPUT
        ref={TEXT_INPUT_REF}
        underlineColorAndroid="transparent"
        editable={false}
        defaultValue="0"
        style={[StyleSheet.absoluteFillObject, styles.textStyle]}
      />
    </View>
  );
}
