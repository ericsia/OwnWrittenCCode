import React, { forwardRef, useEffect, useState, useRef } from "react";
import {
  Text,
  View,
  TouchableOpacity,
  Animated,
  Easing,
  TextInput
} from "react-native";
import { FontAwesome5 } from "@expo/vector-icons";
import { styles } from "./styles";
import { ShakeableTextBoxProps } from "./props";
import { color } from "theme";

export const ShakeableTextBox = forwardRef<TextInput, ShakeableTextBoxProps>(
  (objST: ShakeableTextBoxProps, ref) => {
    // initialise like this (Object Destructuring) so argument is optional
    const {
      isPassword = false,
      containerStyle,
      leftIcon,
      leftIconWrapperStyle,
      title,
      hasError,
      errorMessage,
      iconColor = "#90afff",
      ...TextInputProps
    } = objST;

    // password visibility
    const [visible, setVisible] = useState<boolean>(true);

    useEffect(() => {
      if (hasError) {
        shake();
      }
    }, [hasError]);

    // for purpose of display error
    const ANIMATED = useRef(new Animated.Value(0)).current;
    /* An interpolation maps input ranges to output ranges,
     filling in frames between the key frames 
  */
    const translateX = ANIMATED.interpolate({
      inputRange: [0, 0.5, 1, 1.5, 2, 2.5, 3],
      outputRange: [0, -15, 0, 15, 0, -15, 0]
    });

    function shake() {
      ANIMATED.setValue(0);
      /* Animation duration based on Material Design
           https://material.io/design/motion/speed.html#duration */
      Animated.timing(ANIMATED, {
        duration: 375,
        toValue: 3,
        easing: Easing.bounce,
        useNativeDriver: true
      }).start();
    }
    /*
  Documented by Eric, please give credits if you use it:
  autoCompleteType
  autoFocus default value is false, so do not remove it
  clearButtonMode always supported in iOS
  */
    return (
      <>
        <View style={styles.titleWarpper}>
          {
            /* need to put outside because below is row
             this is how you add code for optional display
             no need [title !== undefined]  direct do like this: */
            title && <Text style={styles.headerTitleStyle}>{title}</Text>
          }
        </View>
        <Animated.View
          style={[
            styles.boxWrapperStyle,
            containerStyle,
            hasError && { borderColor: color.error },
            { transform: [{ translateX }] }
          ]}>
          {
            // this is how you add code for optional display
            leftIcon && <View style={leftIconWrapperStyle}>{leftIcon}</View>
          }
          <TextInput
            ref={ref}
            secureTextEntry={visible}
            style={styles.textboxStyle}
            {...TextInputProps}
          />
          {
            // now for the show password visibility
            isPassword && (
              <TouchableOpacity onPress={() => setVisible(!visible)}>
                <FontAwesome5
                  name={visible ? "eye" : "eye-slash"}
                  size={22}
                  color={iconColor}
                  style={styles.styleIconRight}
                />
              </TouchableOpacity>
            )
          }
        </Animated.View>
        <View>
          {
            /* need to put outside because above is row view
            -record down why you do this so other can refer
             and also convienient for you to look back in future
          */
            errorMessage && (
              <Text style={styles.errorTextStyle}>{errorMessage}</Text>
            )
          }
        </View>
      </>
    );
  }
);
