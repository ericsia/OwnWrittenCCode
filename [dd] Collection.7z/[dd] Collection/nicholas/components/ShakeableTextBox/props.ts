/* Go to https://icons.expo.fyi/  > select filter > tick SimpleLineIcons */
import { TextInputProps, ViewStyle } from "react-native";

export interface ShakeableTextBoxProps extends TextInputProps {
  /** The top label of the textbox */
  title?: string;

  /**
   * Is this field a password
   */
  isPassword?: boolean;

  /**
   * Style for component container
   */
  containerStyle?: ViewStyle;
  /**
   * left icon
   */
  leftIcon?: React.ReactNode;

  /**
   * Styles for LeftIcon wrapper
   */
  leftIconWrapperStyle?: ViewStyle;

  /**
   * Change border of input to red when error
   */
  hasError?: boolean;

  /** Provide custom error message,
   */
  errorMessage?: string;

  iconColor?: string;
}
