import { StyleSheet } from "react-native";
import { color } from "theme";

export const styles = StyleSheet.create({
  titleWarpper: {
    alignSelf: "flex-start"
  },
  boxWrapperStyle: {
    // so the icon can display inside textbox
    backgroundColor: "transparent",
    // if it is blank we need to display the message anyway
    borderColor: color.line,
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: "row",
    height: 41
  },
  /* clearly name it, for text or view or what, if it is ambigous
       don't simply call it errorStyle */
  errorTextStyle: {
    color: color.error,
    fontSize: 11
  },
  headerTitleStyle: {
    color: "#444444",
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 3
  },
  styleIconLeft: {
    // we set the textbox height, so we need to adjust the ocpn center back
    marginTop: 6,
    paddingLeft: 13
  },
  styleIconRight: {
    marginTop: 8,
    paddingRight: 11
  },
  textboxStyle: {
    // flex 1 purpose is for make the content fill
    flex: 1,
    paddingHorizontal: 12
  }
});
