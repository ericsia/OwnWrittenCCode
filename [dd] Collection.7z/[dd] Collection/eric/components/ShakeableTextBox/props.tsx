/* Go to https://icons.expo.fyi/  > select filter > tick SimpleLineIcons */
import { SimpleLineIcons } from "@expo/vector-icons";

/* add a ? behind the variable name to represent it's optional.
     text is for placeholder: the grey text that go away when u type
    
     The idea is you use useState to show the error when submit form
     Use /** to make comment so when others use your component will see it
 */
export interface ShakeableTextBoxProps {
  /** Pick the top textbox set it to true, however if other component
      got this focus feature and is turn on, then ignore this
   */
  focus?: boolean;
  /** The top label of the textbox */
  title?: string;
  /** The text of the placeholder */
  text?: string;
  /** Default is false, if you don't want warning set to true */
  noWarnEmpty?: boolean;
  /** 
      inputType:
      normal= 0      (default no need specify)
      email = 1
      password = 2
  */
  inputType?: 0 | 1 | 2;
  /** 
     To get the textbox result you'll use useState, it is mandatory. The ("") 
     is important, becareful of the N number look at the syntax example:  

               const [result1, setResult1] = useState<string>("");

               const [result2, setResult2] = useState<string>("");


               <ShakeableTextBox
                  focus={true}
                  text="This is called placeholder"
                  resultN={result1}
                  setResultN={(a) => setResult1(a)}
               />
               <ShakeableTextBox
                  leftIconName="magnifier"
                  resultN={result2}
                  setResultN={(a) => setResult2(a)}
               />
  */
  resultN: string;
  setResultN(text: string): void;
  /** The idea of this boolean is to useState turn on the error 
      example when user click submit the form but data is invalid
   */
  showError?: boolean;
  /** Provide custom error message, not required for email  (inputType 1) and 
      password (inputType 2) error message
   */
  errorMessage?: string;
  /** If you want to perform other action when user finished typing set here */
  onComplete?(): void;
  distanceTop?: number;
  /** Note: not required for email  (inputType 1) and password (inputType 2)
      feel free check props most bottom for available SimpleLineIcons icon names
   */
  leftIconName?: keyof typeof SimpleLineIcons.glyphMap;
  /** provide hex color code, you might want set this if you use custom background */
  backColor?: string;
  /** provide hex color code, you might want set this if you use custom background */
  borderColor?: string;
  /** provide hex color code, you might want set this if you use custom background */
  iconColor?: string;
}

/* These are the available icons, use only the icons name provided by SimpleLineIcons
"link" | "menu" | "key" | "map" | "picture" | "minus" | "plus" | "info" | "exclamation" | "check" | "close" | "question" | "home" | "star" | "user" | "phone" | "lock" | "eye" | "camera" | "heart" | "calculator" | "tag" | "calendar" | "hourglass" | "flag" | "printer" | "wallet" | "login" | "logout" | "arrow-down" | "arrow-left" | "arrow-right" | "arrow-up" | "bell" | "briefcase" | "clock" | "compass" | "credit-card" | "crop" | "cup" | "direction" | "drop" | "folder" | "game-controller" | "globe" | "grid" | "layers" | "list" | "location-pin" | "lock-open" | "loop" | "magnet" | "mouse" | "note" | "paper-plane" | "paypal" | "pencil" | "pie-chart" | "pin" | "rocket" | "share" | "shield" | "shuffle" | "trash" | "trophy" | "chart" | "envelope" | "like" | "refresh" | "anchor" | "arrow-down-circle" | "arrow-left-circle" | "arrow-right-circle" | "arrow-up-circle" | "book-open" | "disc" | "film" | "power" | "settings" | "target" | "umbrella" | "volume-1" | "volume-2" | "volume-off" | "ban" | "fire" | "plane" | "feed" | "wrench" | "cloud-download" | "cloud-upload" | "microphone" | "support" | "share-alt" | "diamond" | "envelope-open" | "directions" | "ghost" | "cursor" | "equalizer" | "dislike" | "puzzle" | "social-behance" | "social-dribbble" | "social-dropbox" | "social-facebook" | "social-github" | "social-instagram" | "social-linkedin" | "social-pinterest" | "social-reddit" | "social-skype" | "social-spotify" | "social-steam" | "social-stumbleupon" | "social-tumblr" | "social-twitter" | "social-youtube" | "basket" | "bulb" | "options" | "people" | "reload" | "speedometer" | "cursor-move" | "graph" | "notebook" | "badge" | "call-end" | "event" | "organization" | "user-female" | "user-follow" | "user-following" | "user-unfollow" | "emotsmile" | "call-in" | "call-out" | "options-vertical" | "screen-smartphone" | "screen-desktop" | "mustache" | "energy" | "chemistry" | "screen-tablet" | "magic-wand" | "graduation" | "eyeglass" | "envelope-letter" | "vector" | "speech" | "present" | "playlist" | "handbag" | "globe-alt" | "folder-alt" | "drawer" | "docs" | "doc" | "bubbles" | "basket-loaded" | "bag" | "action-undo" | "action-redo" | "frame" | "size-fullscreen" | "size-actual" | "music-tone-alt" | "music-tone" | "earphones-alt" | "earphones" | "control-start" | "control-rewind" | "control-play" | "control-pause" | "control-forward" | "control-end" | "bubble" | "camrecorder" | "magnifier" | "magnifier-add" | "magnifier-remove" | "paper-clip" | "symbol-female" | "symbol-male" | "social-google" | "social-foursqare" | "social-soundcloud" | "social-vkontakte"
*/
