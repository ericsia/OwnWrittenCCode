/* eslint-disable no-nested-ternary */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-native/no-color-literals */
import React, { useState } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing
} from "react-native";
import { TextInput } from "react-native-gesture-handler";
import { SimpleLineIcons } from "@expo/vector-icons";

// ShakeableTextBoxProps from props.tsx
import { ShakeableTextBoxProps } from "./props";

/* reminder, to make sure every input is correct set your button to fucus
   not clear come ask me what I mean

  For email, you don't need provide validation, icon and set error message.
  Same for password one.
  For safety on submit form you need to check if the content is blank

   in component.tsx:
    - import { ShakeableTextBox } from "components";
    - You need to declare:
        const [tb1Error, setTb1Error] = useState<boolean>(false);
        const [result1, setResult1] = useState<string>("");
    - In return{}, this is how you use it, title is optional:
        <ShakeableTextBox
          title="Nanatsu no Taizai"
          text="This is called placeholder"
          resultN={result1}
          setResultN={(a) => setResult1(a)}
          showError={tb1Error}
        />
    - say if you got button to submit, you call a function check
      the "result1" if it is valid. if not valid setTb1Error(true)
*/
export function ShakeableTextBox(objST: ShakeableTextBoxProps) {
  // initialise like this (Object Destructuring) so argument is optional
  const {
    focus,
    title,
    text = "This field must be filled",
    noWarnEmpty,
    /*
    inputType:
    normal= 0      default
    email = 1
    password = 2
    */
    inputType = 0,
    // should initialise in parent: useState<string>(""); but prevent undefined
    resultN = "",
    setResultN,
    showError,
    errorMessage = inputType === 1
      ? "Your email format is invalid"
      : inputType === 2
      ? "Minimum password length must be more than 5"
      : undefined,
    onComplete = () => undefined,
    distanceTop = 12,
    leftIconName = inputType === 1
      ? "envelope"
      : inputType === 2
      ? "lock"
      : undefined,
    backColor = "transparent",
    borderColor = "#A1C6F7",
    iconColor = "#90afff"
  } = objST;

  const autoComplete =
    inputType === 1 ? "email" : inputType === 2 ? "password" : undefined;
  const keyboardType = inputType === 1 ? "email-address" : "default";
  // password visibility
  const [visible, setVisible] = useState<boolean>(
    // eslint-disable-next-line no-unneeded-ternary
    inputType === 2 ? true : false
  );
  // for purpose of display error
  const [error, setError] = useState(showError);
  const ANIMATED = React.useRef(new Animated.Value(0)).current;
  /* An interpolation maps input ranges to output ranges,
     filling in frames between the key frames 
  */
  const translateX = ANIMATED.interpolate({
    inputRange: [0, 0.5, 1, 1.5, 2, 2.5, 3],
    outputRange: [0, -15, 0, 15, 0, -15, 0]
  });

  function validateInput(input: string, finished: boolean) {
    // if no neeed warn empty can ignore the length
    let valid = true;
    if (inputType === 1) {
      // verify email
      valid = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(input);
    } else if (inputType === 2) {
      // verify minimum length is met
      valid = input.length > 5;
    }
    if ((noWarnEmpty || input.length > 0) && valid) {
      setError(false);
    } else {
      if (finished) {
        ANIMATED.setValue(0);
        /* Animation duration based on Material Design
           https://material.io/design/motion/speed.html#duration */
        Animated.timing(ANIMATED, {
          duration: 375,
          toValue: 3,
          easing: Easing.bounce,
          useNativeDriver: true
        }).start();
      }
      setError(true);
    }
  }

  const styles = StyleSheet.create({
    boxWrapperStyle: {
      // so the icon can display inside textbox
      backgroundColor: backColor,
      // if it is blank we need to display the message anyway
      borderColor: showError || error ? "red" : borderColor,
      borderRadius: 12,
      borderWidth: 1,
      flexDirection: "row",
      height: 41
    },
    /* clearly name it, for text or view or what, if it is ambigous
       don't simply call it errorStyle */
    errorTextStyle: {
      color: "#0c6f5b",
      fontSize: 11
    },
    headerTitleStyle: {
      color: "#444444",
      fontSize: 16,
      fontWeight: "700",
      marginBottom: 3
    },
    styleIconLeft: {
      // we set the textbox height, so we need to adjust the ocpn center back
      marginTop: 6,
      paddingLeft: 13
    },
    styleIconRight: {
      marginTop: 8,
      paddingRight: 11
    },
    textboxStyle: {
      // flex 1 purpose is for make the content fill
      flex: 1,
      paddingHorizontal: 12
    }
  });

  /*
  Documented by Eric, please give credits if you use it:
  autoCompleteType
  autoFocus default value is false, so do not remove it
  clearButtonMode always supported in iOS
  */
  return (
    <>
      <View style={{ alignSelf: "flex-start", marginTop: distanceTop }}>
        {
          /* need to put outside because below is row
             this is how you add code for optional display
             no need [title !== undefined]  direct do like this: */
          title && <Text style={styles.headerTitleStyle}>{title}</Text>
        }
      </View>
      <Animated.View
        style={[styles.boxWrapperStyle, { transform: [{ translateX }] }]}>
        {
          // this is how you add code for optional display
          leftIconName && (
            <SimpleLineIcons
              name={leftIconName}
              size={26}
              color={iconColor}
              style={styles.styleIconLeft}
            />
          )
        }
        <TextInput
          autoCompleteType={autoComplete}
          // default is false
          autoFocus={focus}
          clearButtonMode="always"
          placeholder={text}
          keyboardType={keyboardType}
          secureTextEntry={visible}
          style={styles.textboxStyle}
          onChangeText={(a) => {
            setResultN(a);
            // take note useState got latency so cannot direct check resultN
            validateInput(a, false);
          }}
          // needed because if textbox didn't fill anything
          onBlur={() => {
            validateInput(resultN, true);
            onComplete();
          }}
        />
        {
          // now for the show password visibility
          inputType === 2 && (
            <TouchableOpacity onPress={() => setVisible(!visible)}>
              <SimpleLineIcons
                name="eye"
                size={22}
                color={iconColor}
                style={styles.styleIconRight}
              />
            </TouchableOpacity>
          )
        }
      </Animated.View>
      <View style={{ alignSelf: "flex-start" }}>
        {
          /* need to put outside because above is row view
            -record down why you do this so other can refer
             and also convienient for you to look back in future
          */
          errorMessage && (showError || error) && (
            <Text style={styles.errorTextStyle}>{errorMessage}</Text>
          )
        }
      </View>
    </>
  );
}
