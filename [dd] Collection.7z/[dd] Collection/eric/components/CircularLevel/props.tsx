// stores component props
export interface CircularLevelProps {
  // add a ? behind the variable name to represent it's optional
  currentValue?: number;
  maxValue?: number;
  radiusSize?: number;
  thickness?: number;
  duration?: number;
  color?: string;
}
