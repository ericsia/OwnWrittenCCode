export interface Screen1Props {
  title: string;
  loading: boolean;
  onPressButton: () => void;
}
