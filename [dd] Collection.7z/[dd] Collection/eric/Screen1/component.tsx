import React, { useState } from "react";
import { Text, StyleSheet, View, ImageBackground } from "react-native";
import { Button, CircularLevel, ShakeableTextBox } from "components";
import { observer } from "mobx-react-lite";
import { Root } from "./styles";
import { Screen1Props } from "./props";

const styles = StyleSheet.create({
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
  },
  inputContainerStyle: {
    marginTop: 16,
    width: "90%"
  }
});

// Handles rendering screen, receive data and methods needed from index as props
export const Screen1 = observer((props: Screen1Props) => {
  const { title, onPressButton, loading } = props;
  const [value, setValue] = useState(69);
  const [tb2Error, setTb2Error] = useState<boolean>(false);
  const [result1, setResult1] = useState<string>("");
  const [result2, setResult2] = useState<string>("");
  const [result3, setResult3] = useState<string>("");
  const [result4, setResult4] = useState<string>("");
  // eslint-disable-next-line no-return-assign
  return (
    <ImageBackground
      source={require("../../../assets/images/signup.png")}
      style={styles.image}>
      <Root>
        <Text> {title} </Text>
        <CircularLevel currentValue={value} radiusSize={35} color="blue" />
        <View style={{ width: "78%" }}>
          <ShakeableTextBox
            title="Nanatsu no Taizai"
            text="This is called placeholder"
            noWarnEmpty={true}
            resultN={result1}
            setResultN={(a) => setResult1(a)}
          />
          <ShakeableTextBox
            focus={true}
            text="Notice this is focus?"
            leftIconName="magnifier"
            resultN={result2}
            setResultN={(a) => setResult2(a)}
            showError={tb2Error}
            onComplete={() => alert("You naughty naughty, press search")}
            errorMessage="Location not found, search again"
          />
          <ShakeableTextBox
            inputType={1}
            text="Email no need icon and error msg"
            resultN={result3}
            setResultN={(a) => setResult3(a)}
          />
          <ShakeableTextBox
            inputType={2}
            resultN={result4}
            setResultN={(a) => setResult4(a)}
          />
        </View>

        <Button
          mode="small"
          text="- 23"
          style="marginTop: 10px; marginBottom: 10px"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={() => (value > 0 ? setValue(value - 23) : "")}
        />
        <Button
          mode="small"
          text="reset"
          style="marginBottom: 10px"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={() => (value === 69 ? setValue(0) : setValue(69))}
        />

        {/* This is how you comment */}
        <Button
          mode="small"
          text="Search"
          loading={loading}
          // eslint-disable-next-line no-return-assign
          onPress={() => {
            alert(
              `Hah! your password is -${result4}- now if tb2 not blank show/hide tb2 error`
            );
            setTb2Error(!tb2Error);
          }}
        />
      </Root>
    </ImageBackground>
  );
});
