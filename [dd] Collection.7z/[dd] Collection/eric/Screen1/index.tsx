import React, { useState } from "react";
import { useStores } from "models";
import { Screen1 } from "./component";
// Handles data and methods needed in render and pass it to component.tsx
export const ExampleScreen1 = () => {
  // --------------------STATES & VARIABLES
  const [loading, setLoading] = useState<boolean>(false);

  // --------------------HOOKS

  // --------------------FUNCTIONS
  const onPressButton = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };
  // --------------------RENDER
  return (
    <Screen1
      loading={loading}
      onPressButton={onPressButton}
      title="This is screen1"
    />
  );
};
